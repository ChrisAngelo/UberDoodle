@echo off
title DoodleMinds Studio - Complete Launcher
color 0A

echo.
echo ===========================================================
echo     DOODLEMINDS STUDIO v28 - JACK THE RIPPER EDITION
echo ===========================================================
echo.
echo Starting all services...
echo.

:: Check for Node.js
where node >nul 2>nul
if errorlevel 1 (
    color 0C
    echo [ERROR] Node.js is not installed!
    echo Please install Node.js from https://nodejs.org
    pause
    exit /b 1
)

:: Check for node_modules
if not exist "node_modules" (
    echo [SETUP] Installing dependencies...
    echo This may take a few minutes on first run...
    echo.
    call npm install
    if errorlevel 1 (
        color 0C
        echo [ERROR] npm install failed!
        pause
        exit /b 1
    )
    echo.
    echo [SETUP] Dependencies installed successfully!
    echo.
)

:: Check for .env.local
if not exist ".env.local" (
    echo [CONFIG] Creating default .env.local file...
    echo API_KEY=YOUR_GEMINI_API_KEY_HERE > .env.local
    color 0E
    echo.
    echo [WARNING] Please edit .env.local and add your Gemini API key!
    echo.
)

:: Start CORS Proxy in a new window
echo [STARTING] CORS Proxy Server (Port 3001)...
start "DoodleMinds - CORS Proxy" cmd /k "node cors-proxy.mjs"

:: Give the proxy time to start
timeout /t 3 /nobreak >nul

:: Start Vite development server
echo [STARTING] Vite Development Server (Port 5173)...
echo.
echo ===========================================================
echo   STUDIO IS STARTING...
echo.
echo   Web App:     http://localhost:5173
echo   CORS Proxy:  http://localhost:3002
echo.
echo   Press Ctrl+C to stop the server
echo ===========================================================
echo.

call npm run dev

pause
